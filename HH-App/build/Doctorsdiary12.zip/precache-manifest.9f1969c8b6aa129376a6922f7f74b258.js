self.__precacheManifest = [
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "./static/media/logo.5d5d9eef.svg"
  },
  {
    "revision": "e528a98d1d059d43241005b30d0d4700",
    "url": "./static/media/loading.e528a98d.gif"
  },
  {
    "revision": "4a686d48d5a089750c49",
    "url": "./static/js/runtime~main.4a686d48.js"
  },
  {
    "revision": "842b88585fc7a155c1cb",
    "url": "./static/js/main.842b8858.chunk.js"
  },
  {
    "revision": "21db9da192149e7839ba",
    "url": "./static/js/1.21db9da1.chunk.js"
  },
  {
    "revision": "842b88585fc7a155c1cb",
    "url": "./static/css/main.693c07f1.chunk.css"
  },
  {
    "revision": "2d57a27b3244619a2dd42b5a1ac6631b",
    "url": "./index.html"
  }
];